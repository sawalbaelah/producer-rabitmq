/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.rabit.producer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
/**
 *
 * @author sawal
 */

@Service
public class RabbitMQProducer {
        @Value("${rabbitmq.exchange.name}")
    private String exchange;

    @Value("${rabbitmq.routing.json.key}")
    private String routingJsonKey;
    
    String paylod="{'nama':'sawal','email':'sawalbaelah@gmail.com'}";

    private static final Logger LOGGER = LoggerFactory.getLogger(RabbitMQProducer.class);

    private final RabbitTemplate rabbitTemplate;

    public RabbitMQProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public RabbitTemplate sendJsonMessage(EmailModel emailModel) {
        LOGGER.info(String.format("Json message sent -> %s", emailModel.toString()));
        rabbitTemplate.convertAndSend(exchange, routingJsonKey, emailModel);
        return rabbitTemplate;
    }
}

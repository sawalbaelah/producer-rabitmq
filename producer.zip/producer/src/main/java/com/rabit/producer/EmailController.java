/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.rabit.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author sawal
 */

@RestController
public class EmailController {
    
    @Autowired
    private RabbitMQProducer rabbitProducer;
    
    @GetMapping("/sendEmail")
    private ResponseEntity<String> sendEmail(){
        EmailModel emailModel=new EmailModel();
        emailModel.setNama("sawal");
        emailModel.setEmail("sawalbaelah@gmail.com");
        rabbitProducer.sendJsonMessage(emailModel);
        return ResponseEntity.ok("Sending emsil sukses");
    }
            
}

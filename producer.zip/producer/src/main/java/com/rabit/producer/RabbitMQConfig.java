/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.rabit.producer;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author sawal
 */
@Configuration
public class RabbitMQConfig {

    @Value("${rabbitmq.queue.json.name}")
    private String jsonQueue;

    @Value("${rabbitmq.exchange.name}")
    private String exchange;

    @Value("${rabbitmq.routing.json.key}")
    private String routingJsonKey;

    // spring bean for queue (store json messages)
    @Bean
    public Queue jsonQueue() {
        return new Queue(jsonQueue);
    }

    // spring bean for rabbitmq use topic exchange
    @Bean
    public TopicExchange topicExchange() {
        return new TopicExchange(exchange);
    }
    
     // spring bean for rabbitmq with direct exchange
//    @Bean
//    public DirectExchange directExchange() {
//        return new DirectExchange(exchange);
//    }

    // binding between json queue and exchange using routing key
    @Bean
    public Binding jsonBindingTopic() {
        return BindingBuilder
                .bind(jsonQueue())
                .to(topicExchange())
                .with(routingJsonKey);
    }
    
//     @Bean
//    public Binding jsonBindingDirec() {
//        return BindingBuilder
//                .bind(jsonQueue())
//                .to(directExchange())
//                .with(routingJsonKey);
//    }

    @Bean
    public MessageConverter converter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public AmqpTemplate amqpTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(converter());
        return rabbitTemplate;
    }
}

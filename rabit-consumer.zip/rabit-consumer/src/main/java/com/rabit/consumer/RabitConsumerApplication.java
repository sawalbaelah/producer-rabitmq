package com.rabit.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabitConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabitConsumerApplication.class, args);
	}

}
